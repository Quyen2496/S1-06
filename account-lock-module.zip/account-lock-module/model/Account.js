class Account {
  constructor({ id, username, password }) {
    this.id = id;
    this.username = username;
    this.password = password;

    this.failedLoginAttempts = 0;
    this.lastFailedLoginAt = null;
    this.lockedAt = null;
  }
}

module.exports = Account;
