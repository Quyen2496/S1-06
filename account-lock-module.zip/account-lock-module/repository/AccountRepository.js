class AccountRepository {
  constructor() {
    this.accounts = new Map();
  }

  add(account) {
    this.accounts.set(account.username, account);
    return account;
  }

  findByUsername(username) {
    return this.accounts.get(username) || null;
  }

  save(account) {
    this.accounts.set(account.username, account);
    return account;
  }
}

module.exports = AccountRepository;
