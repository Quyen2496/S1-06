const config = require('../config/accountLock.config');

class AccountLockService {
  constructor(accountRepository, nowProvider = () => new Date()) {
    this.accountRepository = accountRepository;
    this.nowProvider = nowProvider;
  }

  isLocked(account) {
    if (!account.lockedAt) return false;

    const now = this.nowProvider();
    const lockedAt = new Date(account.lockedAt);
    const elapsedMinutes = (now - lockedAt) / 60000;

    if (elapsedMinutes >= config.LOCK_DURATION_MINUTES) {
      this.unlock(account);
      return false;
    }

    return true;
  }

  unlock(account) {
    account.lockedAt = null;
    account.failedLoginAttempts = 0;
    account.lastFailedLoginAt = null;
    this.accountRepository.save(account);
  }

  registerFailedLogin(account) {
    const now = this.nowProvider();

    if (account.lastFailedLoginAt) {
      const elapsedMinutes =
        (now - new Date(account.lastFailedLoginAt)) / 60000;

      if (elapsedMinutes > config.FAILURE_WINDOW_MINUTES) {
        account.failedLoginAttempts = 0;
      }
    }

    account.failedLoginAttempts += 1;
    account.lastFailedLoginAt = now;

    if (account.failedLoginAttempts >= config.MAX_FAILED_ATTEMPTS) {
      account.lockedAt = now;
    }

    this.accountRepository.save(account);

    return {
      failedLoginAttempts: account.failedLoginAttempts,
      locked: Boolean(account.lockedAt),
    };
  }

  registerSuccessfulLogin(account) {
    account.failedLoginAttempts = 0;
    account.lastFailedLoginAt = null;
    this.accountRepository.save(account);
  }
}

module.exports = AccountLockService;
