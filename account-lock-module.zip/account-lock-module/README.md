# Module: Khóa tài khoản

Chức năng được xây dựng đúng theo dữ liệu trong tài liệu:
- `failedLoginAttempts`: số lần đăng nhập sai.
- `lastFailedLoginAt`: thời điểm đăng nhập sai gần nhất.
- `lockedAt`: thời điểm bắt đầu khóa.
- Đếm tối đa 5 lần sai trong 15 phút.
- Khóa tài khoản 30 phút.
- Từ chối đăng nhập khi tài khoản đang bị khóa.
- Tự mở khóa sau 30 phút.
- Reset bộ đếm khi đăng nhập thành công.

Cấu trúc module:
- `model/Account.js`: dữ liệu tài khoản.
- `repository/AccountRepository.js`: lưu và truy xuất tài khoản.
- `service/AccountLockService.js`: toàn bộ nghiệp vụ khóa/mở khóa.
- `controller/AccountAuthController.js`: xử lý đăng nhập.
- `config/accountLock.config.js`: cấu hình thời gian/số lần sai.
- `test/AccountLockService.test.js`: kiểm thử nghiệp vụ.
