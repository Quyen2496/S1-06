const assert = require('assert');
const Account = require('../model/Account');
const AccountRepository = require('../repository/AccountRepository');
const AccountLockService = require('../service/AccountLockService');
const AccountAuthController = require('../controller/AccountAuthController');

let currentTime = new Date('2026-01-01T08:00:00Z');
const nowProvider = () => new Date(currentTime);

const repository = new AccountRepository();
const lockService = new AccountLockService(repository, nowProvider);
const controller = new AccountAuthController(repository, lockService);

const account = new Account({
  id: 1,
  username: 'quynh',
  password: '123456',
});

repository.add(account);

// 1. Sai 4 lần: chưa khóa.
for (let i = 0; i < 4; i++) {
  const result = controller.login('quynh', 'wrong');
  assert.strictEqual(result.success, false);
}
assert.strictEqual(account.failedLoginAttempts, 4);
assert.strictEqual(account.lockedAt, null);

// 2. Sai lần thứ 5: khóa tài khoản.
controller.login('quynh', 'wrong');
assert.ok(account.lockedAt);

// 3. Khi đang khóa: từ chối đăng nhập.
let result = controller.login('quynh', '123456');
assert.strictEqual(result.success, false);

// 4. Sau 30 phút: tự mở khóa.
currentTime = new Date('2026-01-01T08:30:00Z');
result = controller.login('quynh', '123456');
assert.strictEqual(result.success, true);
assert.strictEqual(account.failedLoginAttempts, 0);
assert.strictEqual(account.lockedAt, null);

// 5. Đăng nhập sai rồi thành công: reset bộ đếm.
controller.login('quynh', 'wrong');
assert.strictEqual(account.failedLoginAttempts, 1);
result = controller.login('quynh', '123456');
assert.strictEqual(result.success, true);
assert.strictEqual(account.failedLoginAttempts, 0);

console.log('Tất cả test Account Lock đều PASS.');
