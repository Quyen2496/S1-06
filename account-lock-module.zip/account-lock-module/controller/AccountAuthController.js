class AccountAuthController {
  constructor(accountRepository, accountLockService) {
    this.accountRepository = accountRepository;
    this.accountLockService = accountLockService;
  }

  login(username, password) {
    const account = this.accountRepository.findByUsername(username);

    if (!account) {
      return {
        success: false,
        message: 'Tên đăng nhập hoặc mật khẩu không đúng.',
      };
    }

    if (this.accountLockService.isLocked(account)) {
      return {
        success: false,
        message: 'Tài khoản đang bị khóa.',
      };
    }

    if (account.password !== password) {
      const result = this.accountLockService.registerFailedLogin(account);

      if (result.locked) {
        return {
          success: false,
          message: 'Tài khoản đã bị khóa trong 30 phút.',
        };
      }

      return {
        success: false,
        message: 'Tên đăng nhập hoặc mật khẩu không đúng.',
        failedLoginAttempts: result.failedLoginAttempts,
      };
    }

    this.accountLockService.registerSuccessfulLogin(account);

    return {
      success: true,
      message: 'Đăng nhập thành công.',
    };
  }
}

module.exports = AccountAuthController;
