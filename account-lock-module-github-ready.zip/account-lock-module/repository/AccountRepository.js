/**
 * Repository mẫu để test/local.
 *
 * Khi ghép vào dự án thật, có thể thay repository này bằng repository/DAO
 * đang có của team. AccountLockService chỉ cần repository.save(account).
 */
class AccountRepository {
  constructor() {
    this.accounts = new Map();
  }

  add(account) {
    this.accounts.set(account.username, account);
    return account;
  }

  findByUsername(username) {
    return this.accounts.get(username) || null;
  }

  save(account) {
    this.accounts.set(account.username, account);
    return account;
  }
}

module.exports = AccountRepository;
