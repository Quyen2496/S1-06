const assert = require('assert');
const AccountLockService = require('../service/AccountLockService');
const AccountRepository = require('../repository/AccountRepository');
const Account = require('../model/Account');

let currentTime = new Date('2026-01-01T08:00:00.000Z');
const repository = new AccountRepository();
const service = new AccountLockService({
  repository,
  now: () => new Date(currentTime),
});

const account = new Account({
  id: 1,
  username: 'quynh',
  password: '123456',
});
repository.add(account);

// 4 lần sai trong 15 phút: chưa khóa.
for (let i = 0; i < 4; i++) {
  const result = service.registerFailedLogin(account);
  assert.strictEqual(result.locked, false);
}
assert.strictEqual(account.failedLoginAttempts, 4);
assert.strictEqual(account.lockedAt, null);

// Lần thứ 5: khóa.
const fifth = service.registerFailedLogin(account);
assert.strictEqual(fifth.locked, true);
assert.ok(account.lockedAt);

// Đang khóa: bị từ chối.
assert.strictEqual(service.isLocked(account), true);

// Đúng 30 phút: tự mở khóa.
currentTime = new Date('2026-01-01T08:30:00.000Z');
assert.strictEqual(service.isLocked(account), false);
assert.strictEqual(account.lockedAt, null);
assert.strictEqual(account.failedLoginAttempts, 0);

// Sai rồi đăng nhập thành công: reset bộ đếm.
service.registerFailedLogin(account);
assert.strictEqual(account.failedLoginAttempts, 1);
service.registerSuccessfulLogin(account);
assert.strictEqual(account.failedLoginAttempts, 0);
assert.strictEqual(account.lastFailedLoginAt, null);

console.log('PASS: Account Lock Module');
