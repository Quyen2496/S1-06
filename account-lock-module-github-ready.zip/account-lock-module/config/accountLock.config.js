module.exports = Object.freeze({
  MAX_FAILED_ATTEMPTS: 5,
  FAILURE_WINDOW_MS: 15 * 60 * 1000,
  LOCK_DURATION_MS: 30 * 60 * 1000,
});
