const AccountLockService = require('./service/AccountLockService');
const AccountRepository = require('./repository/AccountRepository');
const AccountAuthController = require('./controller/AccountAuthController');
const config = require('./config/accountLock.config');

module.exports = {
  AccountLockService,
  AccountRepository,
  AccountAuthController,
  config,
};
