const defaultConfig = require('../config/accountLock.config');

/**
 * Nghiệp vụ khóa tài khoản.
 * Không phụ thuộc Express/DB/framework nên có thể ghép vào module của thành viên khác.
 */
class AccountLockService {
  constructor({ repository, now = () => new Date(), config = defaultConfig }) {
    if (!repository) {
      throw new Error('AccountLockService requires a repository');
    }

    this.repository = repository;
    this.now = now;
    this.config = config;
  }

  isLocked(account) {
    if (!account.lockedAt) return false;

    const now = this.now();
    const lockedAt = new Date(account.lockedAt);

    if (now.getTime() - lockedAt.getTime() >= this.config.LOCK_DURATION_MS) {
      this.unlock(account);
      return false;
    }

    return true;
  }

  registerFailedLogin(account) {
    const now = this.now();

    if (account.lastFailedLoginAt) {
      const elapsed =
        now.getTime() - new Date(account.lastFailedLoginAt).getTime();

      if (elapsed > this.config.FAILURE_WINDOW_MS) {
        account.failedLoginAttempts = 0;
      }
    }

    account.failedLoginAttempts = (account.failedLoginAttempts || 0) + 1;
    account.lastFailedLoginAt = now.toISOString();

    if (account.failedLoginAttempts >= this.config.MAX_FAILED_ATTEMPTS) {
      account.lockedAt = now.toISOString();
    }

    this.repository.save(account);

    return {
      failedLoginAttempts: account.failedLoginAttempts,
      locked: this.isLocked(account),
    };
  }

  registerSuccessfulLogin(account) {
    account.failedLoginAttempts = 0;
    account.lastFailedLoginAt = null;
    this.repository.save(account);
  }

  unlock(account) {
    account.failedLoginAttempts = 0;
    account.lastFailedLoginAt = null;
    account.lockedAt = null;
    this.repository.save(account);
  }
}

module.exports = AccountLockService;
