# S1 - Module Khóa tài khoản

## Phạm vi theo tài liệu
- `failedLoginAttempts`
- `lastFailedLoginAt`
- `lockedAt`
- 5 lần đăng nhập sai trong 15 phút
- khóa 30 phút
- từ chối đăng nhập khi đang khóa
- tự mở khóa sau 30 phút
- reset bộ đếm khi đăng nhập thành công

## Thiết kế để ghép GitHub team
Module dùng CommonJS và dependency injection, không phụ thuộc Express, database hay framework cụ thể.

Public API nằm ở `index.js`.

### Khi ghép vào code đăng nhập hiện có

```js
const { AccountLockService } = require('./account-lock-module');

const accountLockService = new AccountLockService({
  repository: accountRepository
});

// Trước khi kiểm tra mật khẩu:
if (accountLockService.isLocked(account)) {
  // trả về "Tài khoản đang bị khóa"
}

// Nếu mật khẩu sai:
accountLockService.registerFailedLogin(account);

// Nếu mật khẩu đúng:
accountLockService.registerSuccessfulLogin(account);
```

Repository thật của team chỉ cần có:
```js
save(account)
```

Không cần copy `AccountRepository.js` và `AccountAuthController.js` nếu dự án đã có sẵn hai phần này.

## Git
Nên commit module thành một commit riêng, ví dụ:
`feat(auth): add account lock module`

Sau khi merge, import `index.js` hoặc import trực tiếp `service/AccountLockService.js`.
