/**
 * Model mẫu cho test/demo.
 * Nếu dự án đã có Account/User model, không cần dùng file này.
 */
class Account {
  constructor({ id, username, password }) {
    this.id = id;
    this.username = username;
    this.password = password;
    this.failedLoginAttempts = 0;
    this.lastFailedLoginAt = null;
    this.lockedAt = null;
  }
}

module.exports = Account;
